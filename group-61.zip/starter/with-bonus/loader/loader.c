#include "loader.h"

Elf32_Ehdr *ehdr;
Elf32_Phdr *phdr;
int fd;
void* virtual_mem = NULL;


// free the allcated space from memory
void loader_cleanup() {
    if (fd >= 0) {
        close(fd);
    }
    if (virtual_mem != MAP_FAILED) {
        (virtual_mem, phdr->p_memsz);
    }
    free(ehdr);
    free(phdr);
}

void load_and_run_elf(char** exe) {

    fd = open(exe[1], O_RDONLY);

    if (fd < 0) {
        printf("Failed to open ELF file\n");
        exit(1);
    }

    // Necessary checks
    size_t file_size = lseek(fd, 0, SEEK_END);
    if (file_size <= 0) {
        printf("ERROR\n");
        exit(1);    
    }
    lseek(fd, 0, SEEK_SET);

    // 1. Load entire binary content into the memory from the ELF file.

    // allocate memory for copying binary content
    // and then read from the file descriptor

    ehdr = (Elf32_Ehdr*)malloc(sizeof(Elf32_Ehdr));
    // validate copied binary content size
    if (read(fd, ehdr, sizeof(Elf32_Ehdr)) != sizeof(Elf32_Ehdr)) {
        printf("Failed to read elf header\n");
    }
    
    phdr = (Elf32_Phdr*)malloc(sizeof(Elf32_Phdr)*(ehdr->e_phnum));
    lseek(fd, ehdr->e_phoff, SEEK_SET);

    // validate copied binary content size
    if (read(fd, phdr, sizeof(Elf32_Phdr) * ehdr->e_phnum) != sizeof(Elf32_Phdr)*(ehdr->e_phnum)) {
        printf("Failed to read program header\n");
    }
    
    // 2. Iterate through the PHDR table and find the section of PT_LOAD 
    for (int i = 0; i < ehdr->e_phnum; i++) {
        if (phdr[i].p_type == PT_LOAD) {

            // 3. Allocate memory of the size "p_memsz" using mmap function
            // and then copy the segment content
            virtual_mem = mmap((void*)phdr[i].p_vaddr, phdr[i].p_memsz,
                               PROT_READ | PROT_WRITE | PROT_EXEC,
                               MAP_ANONYMOUS | MAP_PRIVATE, 0, 0);
            if (virtual_mem == MAP_FAILED) {
                printf("mmap failed\n");
                exit(1);
            }
            if (ehdr->e_entry >= phdr[i].p_vaddr && ehdr->e_entry < phdr[i].p_vaddr + phdr[i].p_memsz) {
                off_t x = lseek(fd, phdr[i].p_offset, SEEK_SET);
                
                if(x <= 0){
                    printf("ERROR\n");
                    exit(1);
                }

                size_t z = read(fd, virtual_mem, phdr[i].p_memsz);
                if(z != phdr[i].p_memsz || z <= 0){
                        printf("Failed to copy the segment content in memory\n");
                        exit(1);
                }
                
                // 4. Navigate to the entrypoint address into the 
                // segment loaded in the memory in above step
                Elf32_Addr relative_dist = ehdr->e_entry - phdr[i].p_vaddr;
                void* actual_entry = (char*)virtual_mem + relative_dist;
                
                // 5. Typecast the address to that of function pointer 
                // matching "_start" method in fib.c.
                int (*_start)(void) = (int (*)(void))(actual_entry);

                // 6. Call the "_start" method and print the value 
                // returned from the "_start"
                int result = _start();
                printf("User _start return value: %d\n", result);
                return;
            }

        }
    }
    printf("e_entry is not valid\n");

}
